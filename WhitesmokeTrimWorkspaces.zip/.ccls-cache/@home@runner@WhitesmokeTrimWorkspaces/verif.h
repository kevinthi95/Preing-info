#ifndef FONCTIONS_H_
#define FONCTIONS_H_


#include <stdio.h>

int verif1(int nb, int n, int m, char tab[n][m]); 

#endif